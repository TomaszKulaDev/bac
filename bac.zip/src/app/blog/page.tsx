export default function Blog() {
  return <h1 className="text-4xl font-bold text-blue-500">Admin Module</h1>;
}
