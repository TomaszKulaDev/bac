// src/app/users/index.tsx
export default function Users() {
  return <h1>Users Module</h1>;
}
